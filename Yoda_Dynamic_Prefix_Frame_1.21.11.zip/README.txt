Yoda Network – Ornate Dynamic Prefix Frame Resource Pack
Minecraft Java 1.21.11 / Resource Pack 75

DESIGN-VERSION
Ornate Pixel Frame v2

KOMPATIBILITÄT ZUR VORVERSION
Font-ID, Zeichenbelegung, Dateinamen, Texturgrößen, Ascent und Höhe sind unverändert.
Das bestehende Plugin kann daher dieselben Glyphen, Space-Glyphen und Breitenwerte weiterverwenden.

ZWECK
Dieses Pack enthält KEINE festen Rangnamen und KEINE festen Farben.
LuckPerms bzw. dein Plugin liefert den aktuellen Prefix-Text (z.B. OWNER / DEVELOPER / MODERATOR).
Das Plugin baut aus neutralen weißen Glyphen einen Rahmen exakt um den Text und färbt Rahmen + Text.

GRAFIK
Die Rahmenkappen besitzen jetzt symmetrische, ornamentale Pixelkerben und kleine Diamant-Akzente.
Die wiederholbare Ober- und Unterkante hat eine dezente zweite Tiefenstufe.
Alle sichtbaren Pixel bleiben neutral weiß/grau und können weiterhin über Adventure/MiniMessage eingefärbt werden.

FONT
Custom Font: yoda:prefix

GLYPHEN
U+E000 = linkes Rahmen-Endstück
U+E001 = 1px breites wiederholbares Mittelstück (oben/unten)
U+E002 = rechtes Rahmen-Endstück
U+E003 = optionaler Punkt/Akzent

SPACE-GLYPHEN (für Overlay/Pixelpositionierung)
U+E100 = -1 px
U+E101 = -2 px
U+E102 = -4 px
U+E103 = -8 px
U+E104 = -16 px
U+E105 = -32 px
U+E106 = -64 px
U+E107 = -128 px
U+E110 = +1 px
U+E111 = +2 px
U+E112 = +4 px
U+E113 = +8 px

PLUGIN-LOGIK (empfohlen)
1. LuckPerms Prefix ohne Farbcodes/Tags auslesen.
2. Gerenderte Pixelbreite des Rangnamens bestimmen.
3. Hintergrund/Rahmen erzeugen:
   E000 + E001 wiederholt (Textbreite + Innenabstand) + E002
4. Cursor mit negativen Space-Glyphen exakt zurücksetzen.
5. Rangnamen über den Rahmen schreiben.
6. Rahmen-Glyphen und Text mit derselben MiniMessage/Adventure-Farbe bzw. demselben Gradient rendern.

WICHTIG
Ein Resourcepack allein kann die Breite eines beliebigen LuckPerms-Prefixes nicht automatisch kennen.
Darum muss das Plugin die Textbreite berechnen und die Anzahl der U+E001-Mittelstücke setzen.
Genau dadurch bleibt das Pack später unverändert, auch wenn neue Prefixe/Farben hinzukommen.

BEISPIEL
Standard OWNER: dunkelrot
Deutschland-Design: Plugin verteilt Schwarz -> Rot -> Gold über Rahmen UND Text.

Hinweis: Für Chat/TAB/NameTags muss das jeweilige Plugin Custom Fonts/Adventure Components unterstützen.
